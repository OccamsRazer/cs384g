===========
Ray Tracing
===========

Jared Croy (jac5659)
jared.croy@gmail.com

Submitted: 5/12/2015

=============
BUILD AND RUN
=============

To build

    make

To run:

    ./bin/ray

====
NOTE
====

In order for the photon mapping to work recursion must be set >= 2 and the scene 
must contain at least one reflective or transmissive object and point lights
